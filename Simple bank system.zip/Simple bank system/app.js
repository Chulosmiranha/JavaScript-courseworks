import { qtd_depositar, qtd_sacar, continuar, escolha_do_menu } from "./exibicao.js"
import { depositar, sacar } from "./financeiro.js"
import { menu } from "./menu.js"

let saldo = 0

export function desicao() {
    const escolha = escolha_do_menu()
    switch (escolha) {
        case 1:
            saldo = depositar(saldo)
            menu()
            break

        case 2:
            saldo = sacar(saldo)
            menu()
            break
        
        case 3:
            console.log(`
            -----------------------------------------------
                                                     
                                                         
                 Você está com um saldo de: R$${saldo}    
                                                         
                                                        
            -----------------------------------------------
            `)
            continuar()
            menu()
            break

        case "Sair":
            break

        default:
            console.log("Opção inválida")
            menu()
            break
    }
}

export function depositado_valido(deposito) {
    while (deposito <= 0) {
        console.log("Valor inválido. O depósito deve ser maior que zero.")
        continuar()
        depositado_valido(qtd_sacar())
    }
    return deposito
}

export function saque_valido(saque) {
    if (saque <= 0) {
        console.log("Valor inválido. O saque deve ser maior que zero.")
        continuar()
        saque_valido(qtd_sacar())
    }
    return saque
}
