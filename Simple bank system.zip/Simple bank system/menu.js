import { desicao } from "./app.js"

export function menu() {
    console.clear()
    console.log(`
        -----------------------------        
        |                           |
        |      1. Depositar         |
        |      2. Sacar             |
        |      3. Exibir saldo      |
        |                           |
        -----------------------------
        |                           |
        |           Sair            |
        |                           |
        ------------------------------
    `);
    desicao()
}
menu()