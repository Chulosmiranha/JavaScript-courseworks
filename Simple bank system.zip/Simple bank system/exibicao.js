import prompt from "prompt-sync"
const ler = prompt()

export function qtd_depositar() {
    return Number(ler("Quanto você deseja depositar: R$"))
}

export function qtd_sacar() {
    return Number(ler("Quanto você deseja sacar: R$"))
}

export function escolha_do_menu() {
    console.log("Digite Sair para sair do programa")
    const escolha = ler("Qual sua escolha: ")
    return escolha.toLowerCase() === "sair" ? "Sair" : Number(escolha)
}

export function continuar() {
    ler("Aperte enter para continuar")
    console.clear()
}
